#!/usr/bin/env python
# -*- coding: UTF-8 -*-
""" API for the ask-owl Microservice """


from functools import lru_cache

from rdflib import Graph
from rdflib.plugins.sparql.processor import SPARQLResult
from baseblock import BaseObject

from askowl.svc import LoadOntologyModel
from askowl.svc import QueryOntologyModel
from askowl.svc import GenerateOntologyLookup
from askowl.dto import QueryResultType


class AskOwlAPI(BaseObject):
    """ API for the ask-owl Microservice """

    def __init__(self,
                 ontology_name: str,
                 absolute_path: str):
        """ Change History

        Created:
            25-May-2022
            craig@grafflr.ai
            *   https://github.com/grafflr/ask-owl/issues/1

        Args:
            ontology_name (str): the name of the Ontology (OWL) model
            absolute_path (str): the absolute path to the OWL model
        """
        BaseObject.__init__(self, __name__)
        self._model_loader = LoadOntologyModel(
            ontology_name=ontology_name,
            absolute_path=absolute_path
        )

        self._execute_query = QueryOntologyModel(
            self._model_loader.graph()
        ).process

    def graph(self) -> Graph:
        return self._model_loader.graph()

    def adhoc(self,
              sparql_query: str) -> SPARQLResult:
        """ Execute an ad-hoc SPARQL query on the OWL model

        Args:
            sparql_query (str): the SPARQL query
                no validation will occur on this query

        Returns:
            SPARQLResult: the SPARQL result set
        """
        return self._execute_query(
            reverse=False,
            sparql=sparql_query,
            result_type=QueryResultType.DO_NOT_TRANSFORM)

    @lru_cache(maxsize=6, typed=False)
    def ngrams(self,
               gram_level: 1) -> list:
        """ Generate n-Grams by Size

        Args:
            gram_level (1): _description_

        Returns:
            list: _description_
        """
        sparql = "SELECT ?a WHERE { ?a rdfs:subClassOf ?b }"

        results = self._execute_query(
            sparql=sparql,
            result_type=QueryResultType.LIST_OF_STRINGS,
        )

        return [x for x in results if x.count('_') == gram_level - 1]

    @lru_cache
    def lookup(self) -> dict:
        """ Generate n-Gram Spans suitable for Synonym Matching

        Reference:
            https://github.com/grafflr/ask-owl/issues/4

        Returns:
            dict: dictionary of values keyed by n-gram size
        """
        sparql = "SELECT ?a ?b WHERE  {  { ?a rdfs:label ?b } UNION { ?a rdfs:seeAlso ?b } }"
        d_results = self._execute_query(
            sparql=sparql,
            result_type=QueryResultType.DICT_OF_STR2LIST,
        )

        return GenerateOntologyLookup().process(d_results)

    @lru_cache(typed=False)
    def by_subject_predicate(self,
                             predicate: str,
                             subject: str) -> list:
        """ Retrieve a list of values by custom subject and custom predicate

        Args:
            predicate (str): the predicate name
            subject (str): the subject name

        Returns:
            list: a list of values for this predicate
        """
        sparql = "SELECT ?b WHERE { #PREFIX:#SUBJECT rdf:type owl:Class ; #PREFIX:#PREDICATE ?b }"
        sparql = sparql.replace('#PREFIX', self._model_loader.prefix)
        sparql = sparql.replace('#PREDICATE', predicate)
        sparql = sparql.replace('#SUBJECT', subject)

        d_results = self._execute_query(
            sparql=sparql,
            result_type=QueryResultType.LIST_OF_STRINGS,
        )

        return d_results

    @lru_cache(typed=False)
    def by_predicate(self,
                     predicate: str,
                     reverse: bool = False) -> list:
        """ Retrieve a list of values by custom predicate

        Args:
            predicate (str): the predicate name
            reverse (bool, optional): reverses the subject/object order. Defaults to False.
                if "?x implies ?y" and reverse=False
                    the results will be { ?x: [?y-1, ?y-2, ..., ?y-N]}
                if "?x implies ?y" and reverse=True
                    the results will be { ?y-1: [x], ?y-2: [x], ?y-N: [x]}

        Returns:
            dict: a dict of values for this predicate
        """
        sparql = "SELECT ?a ?b WHERE { ?a #PREFIX:#PREDICATE ?b }"

        def get_prefix() -> str:
            if ':' in predicate:
                return predicate.split(':')[0].strip()
            return self._model_loader.prefix

        def get_predicate() -> str:
            if ':' in predicate:
                return predicate.split(':')[-1].strip()
            return predicate

        _prefix = get_prefix()
        _predicate = get_predicate()

        sparql = sparql.replace('#PREFIX', _prefix)
        sparql = sparql.replace('#PREDICATE', _predicate)

        print(">>> SPARQL: ", sparql)

        d_results = self._execute_query(
            sparql=sparql,
            reverse=reverse,
            result_type=QueryResultType.DICT_OF_STR2LIST,
        )

        return d_results

    @lru_cache
    def labels(self) -> list:
        """ Retrieve rdfs:label values from the Graph

        Returns:
            list: a list of labels
        """
        sparql = "SELECT ?a WHERE { ?x rdfs:label ?a }"
        return self._execute_query(sparql, QueryResultType.LIST_OF_STRINGS)

    @lru_cache
    def comments(self) -> list:
        """ Retrieve rdfs:comment values from the Graph

        Returns:
            list: a list of labels
        """
        sparql = "SELECT ?a ?b WHERE { ?a rdfs:comment ?b }"

        d_results = self._execute_query(
            sparql=sparql,
            result_type=QueryResultType.DICT_OF_STR2LIST,
        )

        return d_results

    @lru_cache
    def see_also(self) -> list:
        """ Retrieve rdfs:seeAlso values from the Graph

        Returns:
            list: a list of see-also values
        """
        sparql = "SELECT ?a WHERE { ?x rdfs:seeAlso ?a }"
        return self._execute_query(sparql, QueryResultType.LIST_OF_STRINGS)

    @lru_cache
    def backward_compatible_with(self) -> list:
        """ Retrieve owl:backwardCompatibleWith values from the Graph

        Returns:
            list: a list of see-also values
        """
        sparql = "SELECT ?a WHERE { ?x rdfs:seeAlso ?a }"
        return self._execute_query(sparql, QueryResultType.LIST_OF_STRINGS)

    @lru_cache
    def types(self) -> list:
        """ Retrieve rdf:type values from the Graph

        Returns:
            list: a list of labels
        """
        sparql = "SELECT ?a WHERE { ?a rdf:type ?x }"
        return self._execute_query(sparql, QueryResultType.LIST_OF_STRINGS)

from .load_ontology_model import LoadOntologyModel
from .query_ontology_model import QueryOntologyModel
from .generate_ontology_lookup import GenerateOntologyLookup

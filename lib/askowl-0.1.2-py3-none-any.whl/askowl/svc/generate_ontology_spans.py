#!/usr/bin/env python
# -*- coding: UTF-8 -*-
""" Create Ontology Spans using N-Gram Input """


from baseblock import Stopwatch
from baseblock import BaseObject

from askowl.dmo import OwlSpanGenerate
from askowl.dmo import OwlSpanAugment


class GenerateOntologySpans(BaseObject):
    """ Create Ontology Spans using N-Gram Input """

    def __init__(self):
        """ Change History

        Created:
            26-May-2022
            craig@grafflr.ai
            *   https://github.com/grafflr/ask-owl/issues/4
        """
        BaseObject.__init__(self, __name__)

    @staticmethod
    def _sort(tokens: list) -> list:
        values = sorted(set(tokens), key=len)
        values.reverse()
        return values

    def process(self,
                d_results: dict) -> dict:

        sw = Stopwatch()

        d_results = OwlSpanGenerate().process(d_results)
        d_results = OwlSpanAugment().process(d_results)

        d_results[1] = self._sort(d_results[1])
        d_results[2] = self._sort(d_results[2])
        d_results[3] = self._sort(d_results[3])
        d_results[4] = self._sort(d_results[4])
        d_results[5] = self._sort(d_results[5])
        d_results[6] = self._sort(d_results[6])

        if self.isEnabledForInfo:
            self.logger.info('\n'.join([
                "Generated OWL Spans",
                f"\tTotal Time: {str(sw)}",
                f"\tTotal Size: {len(d_results)}"]))

        return d_results
